using System;
using System.Linq;

class MainClass {
  public static void Main (string[] args) {
   
 int minLength = 7; //Setting the minimum length for the password to be 7

 Console.WriteLine("Enter Password");
 string word = Console.ReadLine();

 bool containsAtLeastOneUppercase = word.Any(char.IsUpper);
 bool containsAtLeastOneLowercase = word.Any(char.IsLower);
 bool containsAtSpecialChar = word.Any(ch => ! Char.IsLetterOrDigit(ch));
 bool containsAtLeastOneDigit = word.Any(char.IsDigit);

  Console.WriteLine(word.Length);

  if (word.Length < minLength) //Checks if password is under the desired length
  {
   Console.WriteLine("Password has under 7 characters"); 
  }
  else 
  {
    Console.WriteLine("Password meets length requirement");
  }

  if (containsAtLeastOneUppercase) //Checks for an uppercase character in the password
  {
   Console.WriteLine("Password has one uppercase character");
  }
  else 
  {
    Console.WriteLine("Password needs at least one uppercase character");
  }

  if (containsAtLeastOneLowercase) //Checks for an lowercase character in the password
  {
    Console.WriteLine("Password has one lowercase character");
  }
  else 
  {
    Console.WriteLine("Password needs at least one uppercase character"); 
  }

  if (containsAtSpecialChar) //Checks for a special character in the password
  {
    Console.WriteLine("Password has one special character");
  }
  else
  {
    Console.WriteLine("Password needs at least one special character");
  }

  if (containsAtLeastOneDigit) //Checks for at least one number in the password 
  {
    Console.WriteLine("Password has one number");
  }
  else
  {
    Console.WriteLine("Password needs at least one number");
  }

  char letter;
  int letterCount = 0;
  //loop through each letter
  
  bool hasConsecutive = false; 
  
  for (int i=0; i<word.Length;i++){

    //check character
    letter = word[i];
    letterCount=0;
    //loop through each character in word and compare against each letter
    for(int j=0; j<word.Length;j++){

      //if a matching character is found
      if (letter.Equals(word[j])){
        letterCount++;
 
        

        if (letterCount > 2){
          
          hasConsecutive = true; 
          
          break; //Cancels the count if it goes over 3 
        }
      }
      
    }
    
  }
 if (hasConsecutive) {
   Console.WriteLine("You cannot have the same consecutive 3 characters in your password"); 
 }

  }
}