using System;

class MainClass {
  public static void Main (string[] args) {
   
 int[] A = {3,5,2,1,7,4};

 int HighestCount = 0;
 int IntegerCount = 0;
 int Temp = 0;

 Array.Sort(A); //Sorts the Array defined above 

 for (int i = 0; i < A.Length; i++)
{
   Temp += A[i]; //Adds the array values

   if (Temp > 14) 
   {
     break; //Stops if 'T' equals to more than 14
   }
    else
    {
      HighestCount += A[i]; //if not, add values
      IntegerCount++; //add a value to 'IntegerCount' 
    }
}
 
 Console.WriteLine($"The Highest Number that can be made is {HighestCount}");

 Console.WriteLine($"The Maximum amount of integers that can be made is {IntegerCount}");
 
  }
}