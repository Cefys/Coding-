using System;
using System.Collections.Generic;
using System.Linq;

class MainClass {
  public static void Main (string[] args) {

    string Characters = "XXXYXYXXYYYXYYYYXX";

    List<string> Event = new List<string>(); 

    int XCounter = 0; //Counters for the characters in the string
    int YCounter = 0;

    foreach (char character in Characters) //Loops through characters in the string
    {
      if (character != 'Y')
      {
        Event.Add(new string('Y', YCounter)); //New string with YCounter length and value 

        XCounter++; //Adds 1 to the XCounter
        YCounter = 0; //Resets YCounter to 0
      
      } else 
      {
          Event.Add(new string('X', XCounter)); //New string with XCounter lenght and value

          YCounter++; //Adds 1 to the YCounter
          XCounter = 0; //Resets XCounter to 0 

      } 
    
    }

    foreach (var myVariable in Event) { //Prints all substrings to the console 
      Console.WriteLine(myVariable); 
    }
    
  }
}