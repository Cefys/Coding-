using System;
using System.Linq;

class MainClass {
  public static void Main (string[] args) {
  
int[] arr_one = {9,88,1,9,88,87,35,12,50,23,12,1,4,9}; //Array value
int[] removerepeat = arr_one.Distinct().ToArray(); 

Array.Sort(removerepeat, (x,y) => y.CompareTo(x)); //Sorts the array values in highest to lowest order
Array.ForEach<int>(removerepeat, n => Console.WriteLine(n)); //Sorts the array to remove any repeat values in 'arr_one'

  }
}