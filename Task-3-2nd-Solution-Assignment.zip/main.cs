using System;
using System.Collections;

class MainClass {
    public static void Main(string[] args)
    {
        int[] arr_one = { 9, 88, 1, 9, 88, 87, 35, 12, 50, 23, 12, 1, 4, 9 };
        
         Array.Sort(arr_one); //Sorts the array
         Array.Reverse(arr_one); //Reverses the order of the values in the array
        
        var List = new ArrayList(); //Creates a new list 
        for (int i = 0; i < arr_one.Length; i++) //Continues looping as long as i is less than the array.length 
        {
            if (List.Contains(arr_one[i]) == false) //Checking if the list contains the array
            {
                List.Add(arr_one[i]); //Adds the array to the list 
            }
        }
       
       var New = List.ToArray(); //New list for sorted array
        for (int i = 0; i < New.Length; i++) 
        {
            Console.WriteLine(New[i]); //Inputs new sorted values 
        }
    }
}
