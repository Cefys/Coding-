using System;
using System.Collections.Generic;

class MainClass {
  public static void Main (string[] args) {
  List<string> combinations = Combinations("abc");
  foreach (var combination in combinations){

    Console.WriteLine(combination); 
  }
  }

  public static List<string> Combinations(string abc) {

   

   if (abc.Length < 2)
        return new List<string>() { abc };

   char l = abc[abc.Length - 1]; //Reads the last character 

   List<string> returnList = Combinations(abc.Substring(0, abc.Length - 1)); //Except from the last character, read other characters

   List<string> solution = new List<string>(); //List for combinations 

   foreach (string f in returnList) //Adds characters from previous routine
        solution.Add(f); 

   solution.Add(l.ToString()); //Takes last character 

   foreach (string f in returnList) //Takes the combination from the last character and string from the last routine
        solution.Add(l + f); 

   return solution; 

  }
    
  
  }
 

